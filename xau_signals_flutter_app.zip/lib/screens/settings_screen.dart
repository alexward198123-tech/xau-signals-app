import 'package:flutter/material.dart';
import '../models/app_settings.dart';

class SettingsScreen extends StatefulWidget {
  final AppSettings initial;
  const SettingsScreen({super.key, required this.initial});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _baseUrl;
  late final TextEditingController _apiKey;
  late final TextEditingController _symbol;
  String _timeDisplay = 'uk';

  @override
  void initState() {
    super.initState();
    _baseUrl = TextEditingController(text: widget.initial.baseUrl);
    _apiKey = TextEditingController(text: widget.initial.apiKey);
    _symbol = TextEditingController(text: widget.initial.symbol);
    _timeDisplay = widget.initial.timeDisplay;
  }

  @override
  void dispose() {
    _baseUrl.dispose();
    _apiKey.dispose();
    _symbol.dispose();
    super.dispose();
  }

  void _save() {
    final s = AppSettings(
      baseUrl: _baseUrl.text.trim(),
      apiKey: _apiKey.text.trim(),
      symbol: _symbol.text.trim().isEmpty ? 'XAUUSD' : _symbol.text.trim().toUpperCase(),
      timeDisplay: _timeDisplay,
    );
    Navigator.of(context).pop(s);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        actions: [
          TextButton(
            onPressed: _save,
            child: const Text('SAVE'),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _baseUrl,
            decoration: const InputDecoration(
              labelText: 'Backend Base URL',
              hintText: 'https://yourdomain.com',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _apiKey,
            decoration: const InputDecoration(
              labelText: 'API Key',
              hintText: 'Same as backend API_KEY',
            ),
            obscureText: true,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _symbol,
            decoration: const InputDecoration(
              labelText: 'Symbol',
              hintText: 'XAUUSD',
            ),
          ),
          const SizedBox(height: 18),
          const Text('Display time in', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          RadioListTile(
            value: 'uk',
            groupValue: _timeDisplay,
            onChanged: (v) => setState(() => _timeDisplay = v as String),
            title: const Text('UK (GMT)'),
          ),
          RadioListTile(
            value: 'broker',
            groupValue: _timeDisplay,
            onChanged: (v) => setState(() => _timeDisplay = v as String),
            title: const Text('Broker server (Dubai)'),
          ),
          const SizedBox(height: 18),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('Tip', style: TextStyle(fontWeight: FontWeight.w700)),
                  SizedBox(height: 8),
                  Text(
                    'If you are testing on an Android emulator with your backend running on your computer, '
                    'use base URL: http://10.0.2.2:8080',
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
