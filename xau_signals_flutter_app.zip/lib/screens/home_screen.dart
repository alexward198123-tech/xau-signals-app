import 'package:flutter/material.dart';

import '../models/app_settings.dart';
import '../models/signal_payload.dart';
import '../models/alert_payload.dart';
import '../services/settings_store.dart';
import '../services/api_service.dart';
import '../widgets/signal_card.dart';
import '../widgets/alert_card.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _store = SettingsStore();
  AppSettings _settings = AppSettings.defaults;

  bool _loading = true;
  SignalPayload? _latest;
  List<SignalPayload> _history = const [];
  List<AlertPayload> _alerts = const [];

  int _tabIndex = 0;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final s = await _store.load();
    setState(() {
      _settings = s;
    });
    await _refresh();
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    final api = ApiService(_settings);
    final latest = await api.fetchLatestSignal();
    final history = await api.fetchSignalHistory(limit: 100);
    final alerts = await api.fetchAlerts(limit: 50);
    setState(() {
      _latest = latest;
      _history = history;
      _alerts = alerts;
      _loading = false;
    });
  }

  Future<void> _openSettings() async {
    final updated = await Navigator.of(context).push<AppSettings>(
      MaterialPageRoute(builder: (_) => SettingsScreen(initial: _settings)),
    );
    if (updated != null) {
      await _store.save(updated);
      setState(() => _settings = updated);
      await _refresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _LatestTab(
        loading: _loading,
        latest: _latest,
        timeMode: _settings.timeDisplay,
        onRefresh: _refresh,
      ),
      _HistoryTab(
        loading: _loading,
        history: _history,
        timeMode: _settings.timeDisplay,
        onRefresh: _refresh,
      ),
      _AlertsTab(
        loading: _loading,
        alerts: _alerts,
        onRefresh: _refresh,
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text('XAU Signals (${_settings.symbol})'),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            icon: const Icon(Icons.refresh),
            onPressed: _refresh,
          ),
          IconButton(
            tooltip: 'Settings',
            icon: const Icon(Icons.settings),
            onPressed: _openSettings,
          ),
        ],
      ),
      body: pages[_tabIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tabIndex,
        onDestinationSelected: (i) => setState(() => _tabIndex = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.bolt), label: 'Latest'),
          NavigationDestination(icon: Icon(Icons.history), label: 'History'),
          NavigationDestination(icon: Icon(Icons.warning_amber), label: 'Alerts'),
        ],
      ),
    );
  }
}

class _LatestTab extends StatelessWidget {
  final bool loading;
  final SignalPayload? latest;
  final String timeMode;
  final Future<void> Function() onRefresh;

  const _LatestTab({
    required this.loading,
    required this.latest,
    required this.timeMode,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (latest == null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('No signal yet.'),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: onRefresh,
              icon: const Icon(Icons.refresh),
              label: const Text('Try again'),
            ),
          ],
        ),
      );
    }
    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          SignalCard(signal: latest!, timeMode: timeMode),
          const SizedBox(height: 12),
          _DisclaimerCard(),
        ],
      ),
    );
  }
}

class _HistoryTab extends StatelessWidget {
  final bool loading;
  final List<SignalPayload> history;
  final String timeMode;
  final Future<void> Function() onRefresh;

  const _HistoryTab({
    required this.loading,
    required this.history,
    required this.timeMode,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    if (history.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('No history yet.'),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: onRefresh,
              icon: const Icon(Icons.refresh),
              label: const Text('Refresh'),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: history.length,
        itemBuilder: (_, i) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: SignalCard(signal: history[i], timeMode: timeMode),
        ),
      ),
    );
  }
}

class _AlertsTab extends StatelessWidget {
  final bool loading;
  final List<AlertPayload> alerts;
  final Future<void> Function() onRefresh;

  const _AlertsTab({
    required this.loading,
    required this.alerts,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    if (alerts.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('No alerts.'),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: onRefresh,
              icon: const Icon(Icons.refresh),
              label: const Text('Refresh'),
            ),
          ],
        ),
      );
    }
    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: alerts.length,
        itemBuilder: (_, i) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: AlertCard(alert: alerts[i]),
        ),
      ),
    );
  }
}

class _DisclaimerCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text('Disclaimer', style: TextStyle(fontWeight: FontWeight.w700)),
            SizedBox(height: 8),
            Text(
              'This app provides trading signals and educational information only. '
              'It does not guarantee profits. Trading involves risk and you can lose money. '
              'You are responsible for your own trades.',
            ),
          ],
        ),
      ),
    );
  }
}
